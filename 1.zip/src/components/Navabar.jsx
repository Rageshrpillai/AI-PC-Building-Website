import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

import logo from "../assets/logo.png";
import specsIcon from "../assets/icons.png";

const NAV_LINKS = [
  { name: "HOME", to: "/" },
  { name: "COLLECTION", to: "/spec" },
  { name: "ABOUT", to: "/about" },
  { name: "CONTACT", to: "/contact" },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`
        fixed top-0 left-0 w-full z-50  h-16 px-5 flex items-center justify-between
        transition-colors duration-200
        ${
          isScrolled
            ? "bg-[#100C16] text-gray-200"
            : "bg-transparent text-gray-500"
        }
      `}
    >
      {/* Logo */}
      <img src={logo} alt="Logo" className="h-8" />

      {/* Navigation Links (hidden on small screens) */}
      <div className="hidden md:flex space-x-10">
        {NAV_LINKS.map(({ name, to }) => (
          <NavLink key={to} to={to} className="font-medium hover:text-white">
            {name}
          </NavLink>
        ))}
      </div>

      {/* “Specs” Button */}
      <button
        className="
          inline-flex items-center gap-2.5 
          px-4 py-2 
          bg-[#7907E5] text-white 
          rounded-md
        "
      >
        <img src={specsIcon} alt="" className="w-5 h-5" />
        <span className="text-base font-medium leading-6">Specs</span>
      </button>
    </nav>
  );
}
