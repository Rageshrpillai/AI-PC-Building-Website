// src/components/FiltersSidebar.jsx
import React, { useState, useEffect } from "react";

// Updated to reflect common CPU brands present in our mock data
const initialManufacturersData = [
  { id: "intel", name: "Intel", checked: false }, // Start with filters unchecked
  { id: "amd", name: "AMD", checked: false },
];

const initialRatingsData = [
  { id: "5star", label: "★★★★★", count: 123, checked: false },
  { id: "4star", label: "★★★★☆", count: 85, checked: false },
  { id: "3star", label: "★★★☆☆", count: 40, checked: false },
  { id: "2star", label: "★★☆☆☆", count: 15, checked: false },
  { id: "1star", label: "★☆☆☆☆", count: 5, checked: false },
  { id: "unrated", label: "Unrated", count: 22, checked: false },
];

const FilterCheckbox = ({ id, label, checked, onChange, count }) => (
  <label
    htmlFor={id}
    className="flex items-center space-x-2 cursor-pointer hover:text-purple-300"
  >
    <input
      type="checkbox"
      id={id}
      checked={checked}
      onChange={onChange}
      className="h-4 w-4 rounded bg-gray-700 border-gray-600 text-purple-500 focus:ring-purple-600 focus:ring-offset-gray-800"
    />
    <span className="text-sm">{label}</span>
    {count !== undefined && (
      <span className="text-xs text-gray-500">({count})</span>
    )}
  </label>
);

export default function FiltersSidebar({
  onBrandFilterChange,
  onRatingFilterChange,
}) {
  const [openSections, setOpenSections] = useState({
    merchants: false,
    manufacturer: true,
    formFactor: false,
    rating: true,
  });

  const [manufacturers, setManufacturers] = useState(initialManufacturersData);
  const [ratings, setRatings] = useState(initialRatingsData);

  useEffect(() => {
    if (onBrandFilterChange) {
      const selectedBrandNames = manufacturers
        .filter((m) => m.checked)
        .map((m) => m.name);
      onBrandFilterChange(selectedBrandNames);
    }
  }, [manufacturers, onBrandFilterChange]);

  useEffect(() => {
    if (onRatingFilterChange) {
      const selectedRatingIds = ratings
        .filter((r) => r.checked)
        .map((r) => r.id);
      onRatingFilterChange(selectedRatingIds);
    }
  }, [ratings, onRatingFilterChange]);

  const handleToggleSection = (sectionName) => {
    setOpenSections((prev) => ({ ...prev, [sectionName]: !prev[sectionName] }));
  };

  const handleManufacturerChange = (manufacturerId) => {
    setManufacturers((prev) =>
      prev.map((m) =>
        m.id === manufacturerId ? { ...m, checked: !m.checked } : m
      )
    );
  };

  const handleRatingChange = (ratingId) => {
    setRatings((prev) =>
      prev.map((r) => (r.id === ratingId ? { ...r, checked: !r.checked } : r))
    );
  };

  function renderFilterSection(sectionName, title, children) {
    const isOpen = openSections[sectionName];
    return (
      <div className="space-y-1 border-b border-gray-700 pb-4 last:border-b-0 last:pb-0">
        <button
          onClick={() => handleToggleSection(sectionName)}
          className="flex items-center justify-between w-full py-2 text-left focus:outline-none"
        >
          <h3 className="text-sm font-semibold uppercase text-gray-400 tracking-wider">
            {title}
          </h3>
          <span className="text-purple-400 transform transition-transform duration-200">
            {isOpen ? "▼" : "►"}
          </span>
        </button>
        {isOpen && <div className="animate-fadeIn pt-1">{children}</div>}
      </div>
    );
  }

  return (
    <aside className="w-full md:w-72 bg-[#1A1325] p-6 rounded-lg text-gray-300 space-y-6">
      <div>
        <input
          type="text"
          placeholder="Filters"
          className="w-full px-4 py-2.5 rounded-md bg-[#100C16] border border-gray-700 placeholder-gray-500 text-gray-200 focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500"
        />
      </div>

      {/* Corrected children for Merchants */}
      {renderFilterSection(
        "merchants",
        "Merchants",
        <div className="text-gray-400 text-sm pt-2">
          <p>Merchant filter options will appear here.</p>
        </div>
      )}

      {renderFilterSection(
        "manufacturer",
        "Manufacturer",
        <>
          <div className="space-y-2 pt-2">
            {manufacturers.map((manufacturer) => (
              <FilterCheckbox
                key={manufacturer.id}
                id={`manufacturer-${manufacturer.id}`}
                label={manufacturer.name}
                checked={manufacturer.checked}
                onChange={() => handleManufacturerChange(manufacturer.id)}
              />
            ))}
          </div>
          {/* <button className="text-xs text-purple-400 hover:text-purple-300 mt-2">Show more</button> */}
        </>
      )}

      {/* Corrected children for Form Factor */}
      {renderFilterSection(
        "formFactor",
        "Form Factor",
        <div className="text-gray-400 text-sm pt-2">
          <p>Form factor options (e.g., ATX, Micro-ATX) will appear here.</p>
        </div>
      )}

      {renderFilterSection(
        "rating",
        "Rating",
        <>
          <div className="space-y-2 pt-2">
            {ratings.map((rating) => (
              <FilterCheckbox
                key={rating.id}
                id={`rating-${rating.id}`}
                label={rating.label}
                checked={rating.checked}
                onChange={() => handleRatingChange(rating.id)}
              />
            ))}
          </div>
          {/* <button className="text-xs text-purple-400 hover:text-purple-300 mt-2">Show more</button> */}
        </>
      )}
    </aside>
  );
}
