// src/pages/Spec.jsx (or SpecsListPage.jsx)
import React, { useState, useEffect, useMemo } from "react";
import { fetchProducts } from "../services/apiService";
import PartCard from "../components/PartCard";
import FiltersSidebar from "../components/FiltersSidebar";
import Navabar from "../components/Navabar";

// You'll need to define your ratingCriteria if you keep the rating filter
// This was based on FakeStoreAPI and will need adjustment for new data
const ratingCriteria = {
  "5star": (rate) => rate >= 4.5,
  "4star": (rate) => rate >= 3.5 && rate < 4.5,
  "3star": (rate) => rate >= 2.5 && rate < 3.5,
  "2star": (rate) => rate >= 1.5 && rate < 2.5,
  "1star": (rate) => rate > 0 && rate < 1.5,
};

export default function SpecsListPage() {
  // Or export default function Spec()
  const [allProducts, setAllProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("components");

  const [selectedRatingFilters, setSelectedRatingFilters] = useState([]);
  const [selectedBrandFilters, setSelectedBrandFilters] = useState([]);

  useEffect(() => {
    if (activeTab === "components") {
      const loadProducts = async () => {
        const categoryToFetch = "cpu"; // Define categoryToFetch here
        try {
          setIsLoading(true);
          setError(null);
          // const categoryToFetch = "cpu"; // No longer here
          const data = await fetchProducts(categoryToFetch);
          console.log("Data received by SpecsListPage:", data); // Good to keep this for now
          if (Array.isArray(data)) {
            setAllProducts(data);
          } else {
            console.error("Fetched data is not an array:", data);
            setAllProducts([]);
          }
        } catch (err) {
          console.error(
            `Error in loadProducts for category ${categoryToFetch}:`,
            err
          );
          setError(err.message || `Failed to fetch ${categoryToFetch}.`); // Now categoryToFetch is in scope
          setAllProducts([]);
        } finally {
          setIsLoading(false);
        }
      };
      loadProducts();
    } else {
      setIsLoading(false);
    }
  }, [activeTab]);

  const handleRatingFilterChange = (newSelectedRatings) => {
    setSelectedRatingFilters(newSelectedRatings);
  };

  const handleBrandFilterChange = (newSelectedBrands) => {
    setSelectedBrandFilters(newSelectedBrands);
  };

  const filteredProducts = useMemo(() => {
    let productsToFilter = allProducts;

    // Apply Brand filters
    if (selectedBrandFilters && selectedBrandFilters.length > 0) {
      productsToFilter = productsToFilter.filter(
        (product) =>
          product.brand && selectedBrandFilters.includes(product.brand)
      );
    }

    // Apply Rating filters
    if (selectedRatingFilters && selectedRatingFilters.length > 0) {
      productsToFilter = productsToFilter.filter((product) => {
        // Adjust this logic based on your actual product data structure for ratings
        if (!product.rating || typeof product.rating.rate !== "number") {
          return false;
        }
        return selectedRatingFilters.some((filterId) => {
          const criterion = ratingCriteria[filterId];
          return criterion ? criterion(product.rating.rate) : false;
        });
      });
    }

    return productsToFilter;
  }, [allProducts, selectedBrandFilters, selectedRatingFilters]);

  const renderComponentsContent = () => {
    if (isLoading && allProducts.length === 0) {
      return (
        <div className="flex-grow flex items-center justify-center text-xl text-gray-300 py-10">
          Loading components...
        </div>
      );
    }
    if (error) {
      return (
        <div className="flex-grow flex items-center justify-center text-red-400 p-8 py-10">
          Error: {error}
        </div>
      );
    }

    return (
      <div className="flex flex-col md:flex-row md:space-x-6 lg:space-x-8">
        <div className="w-full md:w-auto md:flex-shrink-0 mb-6 md:mb-0">
          <FiltersSidebar
            onRatingFilterChange={handleRatingFilterChange}
            onBrandFilterChange={handleBrandFilterChange}
          />
        </div>
        <main className="flex-grow">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <PartCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 bg-[#1A1325] rounded-lg">
              <p className="text-center text-gray-400">
                {isLoading
                  ? "Loading..."
                  : "No products match your current filters or none found."}
              </p>
            </div>
          )}
        </main>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#100C16] text-gray-100">
      <Navabar />
      <div className="p-4 sm:p-6 md:p-8">
        <div className="mb-6 sm:mb-8 flex border-b border-gray-700">
          <button
            onClick={() => setActiveTab("components")}
            className={`py-2.5 px-4 sm:py-3 sm:px-6 -mb-px text-sm sm:text-base font-medium focus:outline-none transition-colors duration-150 ${
              activeTab === "components"
                ? "border-b-2 border-purple-500 text-purple-400"
                : "text-gray-500 hover:text-gray-300 hover:border-gray-500 border-b-2 border-transparent"
            }`}
          >
            Components list
          </button>
          <button
            onClick={() => setActiveTab("compare")}
            className={`py-2.5 px-4 sm:py-3 sm:px-6 -mb-px text-sm sm:text-base font-medium focus:outline-none transition-colors duration-150 ${
              activeTab === "compare"
                ? "border-b-2 border-purple-500 text-purple-400"
                : "text-gray-500 hover:text-gray-300 hover:border-gray-500 border-b-2 border-transparent"
            }`}
          >
            Compare
          </button>
        </div>

        {/* Ensure renderComponentsContent is called here */}
        {activeTab === "components" && renderComponentsContent()}

        {activeTab === "compare" && (
          <div className="text-center py-20 bg-[#1A1325] rounded-lg">
            <h2 className="text-2xl font-semibold text-gray-300">
              Compare Feature
            </h2>
            <p className="text-gray-400 mt-2">This section is coming soon!</p>
          </div>
        )}
      </div>
    </div>
  );
}
